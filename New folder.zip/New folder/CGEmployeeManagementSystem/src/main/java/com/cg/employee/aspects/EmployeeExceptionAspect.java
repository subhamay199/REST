package com.cg.employee.aspects;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.employee.exceptions.EmployeeNotFoundException;
import com.cg.employee.response.EmployeeResponse;

@ControllerAdvice
public class EmployeeExceptionAspect {
	@ExceptionHandler(EmployeeNotFoundException.class)
public ResponseEntity<EmployeeResponse> handleEmployeeDetailsNotFoundException(Exception e) {
		EmployeeResponse response=new EmployeeResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
	return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
}
