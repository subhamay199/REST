package com.cg.employee.services;

import java.util.List;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeNotFoundException;

public interface EmployeeServices {
Employee acceptEmployeeDetails(Employee employee);
Employee getEmployeeDetails(int employeeId) throws EmployeeNotFoundException;
List<Employee> getAllEmployeeDetails();
boolean removeEmployeeDetails(int employeeId);
}
