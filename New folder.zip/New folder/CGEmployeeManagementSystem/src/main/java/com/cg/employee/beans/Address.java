package com.cg.employee.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
private int pinCode;
private String city;
private String state;
}
