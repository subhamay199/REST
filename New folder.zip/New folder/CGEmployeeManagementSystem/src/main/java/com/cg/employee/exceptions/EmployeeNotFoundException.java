package com.cg.employee.exceptions;

public class EmployeeNotFoundException extends Exception {

	public EmployeeNotFoundException() {
		super("Employee Not Found");		
	}

	public EmployeeNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);	
	}

	public EmployeeNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public EmployeeNotFoundException(String message) {
		super(message);		
	}

	public EmployeeNotFoundException(Throwable cause) {
		super(cause);
	}
	

}
