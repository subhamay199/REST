package com.cg.employee.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeNotFoundException;
import com.cg.employee.services.EmployeeServices;
@Controller
public class EmployeeServicesController {
	@Autowired
EmployeeServices services;
	
	@RequestMapping(value={"/getEmployeeDetails/{employeeId}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
			public ResponseEntity<Employee> getAssociateDetailsPathParam(@PathVariable(value="employeeId")int employeeId) throws EmployeeNotFoundException{
		Employee employee=services.getEmployeeDetails(employeeId);
				return new ResponseEntity<Employee>(employee,HttpStatus.OK);
			}
			@RequestMapping(value={"/getAllEmployeeDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
			public ResponseEntity<List<Employee>> getAssociateDetailsPathParam() {
					return new ResponseEntity<List<Employee>>(services.getAllEmployeeDetails(),HttpStatus.OK);
			}
			@RequestMapping(value={"/acceptEmployeeDetails"},method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
			public ResponseEntity<String> acceptEmployeeDetails(@ModelAttribute Employee employee) throws EmployeeNotFoundException{
				employee=services.acceptEmployeeDetails(employee);
				return new ResponseEntity<>("Employee details successfully added EmployeeId"+employee.getEmployeeId(),HttpStatus.OK);
			}
			@RequestMapping(value={"/removeEmployeeDetails"},method=RequestMethod.DELETE,produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
			public ResponseEntity<String> removeEmployeeDetails(@RequestParam int employeeId) throws EmployeeNotFoundException{
				services.removeEmployeeDetails(employeeId);
				return new ResponseEntity<>("Employee details successfully Deleted Employee Id",HttpStatus.OK);
			}
}