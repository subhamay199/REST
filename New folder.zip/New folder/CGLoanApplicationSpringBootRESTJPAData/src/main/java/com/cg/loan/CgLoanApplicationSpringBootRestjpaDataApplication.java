package com.cg.loan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgLoanApplicationSpringBootRestjpaDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgLoanApplicationSpringBootRestjpaDataApplication.class, args);
	}

}
