package com.cg.loan.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String customerId;
	private String customerName;
	private String pancard;
	private String mobileNo;
	private String emailId;
	private int cibilScore=(int) (Math.random()*1000);
	
	public Customer() {
		super();
	}

	public Customer(String customerId, String customerName, String pancard, String mobileNo, String emailId) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.pancard = pancard;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPancard() {
		return pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", pancard=" + pancard
				+ ", mobileNo=" + mobileNo + ", emailId=" + emailId + "]";
	}
}
