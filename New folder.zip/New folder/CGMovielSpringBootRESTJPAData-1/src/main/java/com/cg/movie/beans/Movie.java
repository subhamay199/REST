package com.cg.movie.beans;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

@Entity
public class Movie {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int movieId;
private String movieName;
private String musicDirector;
@OneToMany(mappedBy="movie")
@MapKey
private Map<Integer,Music> music;
public Movie() {}
public Movie(int movieId, String movieName, String musicDirector, Map<Integer, Music> music) {
	super();
	this.movieId = movieId;
	this.movieName = movieName;
	this.musicDirector = musicDirector;
	this.music = music;
}
public int getMovieId() {
	return movieId;
}
public void setMovieId(int movieId) {
	this.movieId = movieId;
}
public String getMovieName() {
	return movieName;
}
public void setMovieName(String movieName) {
	this.movieName = movieName;
}
public String getMusicDirector() {
	return musicDirector;
}
public void setMusicDirector(String musicDirector) {
	this.musicDirector = musicDirector;
}
public Map<Integer, Music> getMusic() {
	return music;
}
public void setMusic(Map<Integer, Music> music) {
	this.music = music;
}
@Override
public String toString() {
	return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", musicDirector=" + musicDirector + ", music="
			+ music + "]";
}

}
