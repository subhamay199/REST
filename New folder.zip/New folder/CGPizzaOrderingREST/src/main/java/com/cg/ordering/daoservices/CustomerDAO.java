package com.cg.ordering.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ordering.beans.Customer;

public interface CustomerDAO extends JpaRepository<Customer, Integer> {

}
