package com.cg.ordering.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ordering.beans.Customer;
import com.cg.ordering.beans.PizzaOrder;
import com.cg.ordering.exceptions.CustomerDetailsNotFoundException;
import com.cg.ordering.exceptions.OrderDetailsNotFoundException;
import com.cg.ordering.services.PizzaOrderServices;

@Controller
public class OrderingServiceController {
@Autowired
PizzaOrderServices orderServices;
@RequestMapping(value={"/getCustomerDetails/{customerId}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<Customer> getCustomerDetailsPathParam(@PathVariable(value="customerId")int customerId) throws CustomerDetailsNotFoundException{
	Customer customer=orderServices.getCustomerDetails(customerId);
	return new ResponseEntity<Customer>(customer,HttpStatus.OK);
}
@RequestMapping(value={"/getAllCustomerDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<List<Customer>> getAssociateDetailsPathParam() {
		return new ResponseEntity<List<Customer>>(orderServices.getAllCustomerDetails(),HttpStatus.OK);
}
@RequestMapping(value={"/acceptCustomerDetails"},method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
public ResponseEntity<String> acceptCustomerDetails(@ModelAttribute Customer customer) throws CustomerDetailsNotFoundException{
	customer=orderServices.acceptCustomerDetails(customer);
	return new ResponseEntity<>("Customer details successfully added CustomerId"+customer.getCustomerId(),HttpStatus.OK);
}
@RequestMapping(value={"/removeOrderDetails"},method=RequestMethod.DELETE,produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
public ResponseEntity<String> removeOrderDetails(@RequestParam int orderId) throws CustomerDetailsNotFoundException{
	orderServices.removeOrder(orderId);
	return new ResponseEntity<>("Order details successfully added Order Id",HttpStatus.OK);
}
@RequestMapping(value={"/acceptOrderDetails"},method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
public ResponseEntity<String> acceptOrderDetails(@ModelAttribute PizzaOrder order,@RequestParam int customerId) throws OrderDetailsNotFoundException, CustomerDetailsNotFoundException{
	order=orderServices.acceptOrderDetails(customerId,order);
	return new ResponseEntity<>("Order details successfully added Order Id"+order.getOrderId(),HttpStatus.OK);
}
@RequestMapping(value={"/getAllOrderDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<List<PizzaOrder>> getOrderDetailsPathParam() {
		return new ResponseEntity<List<PizzaOrder>>(orderServices.getAllOrderDetails(),HttpStatus.OK);
}
}
