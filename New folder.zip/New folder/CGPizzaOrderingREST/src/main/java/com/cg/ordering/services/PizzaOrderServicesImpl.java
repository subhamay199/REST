package com.cg.ordering.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.ordering.beans.Customer;
import com.cg.ordering.beans.PizzaOrder;
import com.cg.ordering.daoservices.CustomerDAO;
import com.cg.ordering.daoservices.PizzaOrderDAO;
import com.cg.ordering.exceptions.CustomerDetailsNotFoundException;
import com.cg.ordering.exceptions.OrderDetailsNotFoundException;
@Component("pizzaOrderServices")
public class PizzaOrderServicesImpl implements PizzaOrderServices{
@Autowired
PizzaOrderDAO orderDAO;
	@Autowired
	CustomerDAO customerDAO;
	@Override
	public Customer acceptCustomerDetails(Customer customer) {
		return customerDAO.save(customer);
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerDetailsNotFoundException {
		return customerDAO.findById(customerId).orElseThrow(()->new CustomerDetailsNotFoundException("Customer Details Not Found For The Customer Id"+customerId));
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		return customerDAO.findAll();
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) throws OrderDetailsNotFoundException {
		//Customer customer=customerDAO.findById(customerId).orElseThrow(()->new CustomerDetailsNotFoundException("Customer Details Not Found For The Customer Id"+customerId));
		//PizzaOrder pizzaOrder=getCustomerDetails(customerId).getPizza();
		return orderDAO.findById(orderId).orElseThrow(()->new OrderDetailsNotFoundException("OrderDetails Not Found For The Order Id"+orderId));
	//
	}

	@Override
	public boolean removeOrder(int orderId) {
		orderDAO.deleteById(orderId);
		return true;
		}

	@Override
	public List<PizzaOrder> getAllOrderDetails() {
		return orderDAO.findAll();
	}

	@Override
	public double calculateBillAmount(int customerId, int orderId, int quantity) throws CustomerDetailsNotFoundException {
		//PizzaOrder cPizzaOrder=getCustomerDetails(customerId).getPizza().values();
		return 0;
	}

	@Override
	public PizzaOrder acceptOrderDetails(int customerId,PizzaOrder order) throws CustomerDetailsNotFoundException {
//		Customer customer=getCustomerDetails(customerId);
//		PizzaOrder pizzaOrder=orderDAO.save(customer);
//	 return pizzaOrder;
		Customer customer=getCustomerDetails(customerId);
		order.setCustomer(customer);
		return orderDAO.save(order);
	}

	@Override
	public PizzaOrder acceptOrderDetails(PizzaOrder order) {
		//order.setCustomer(customer.);
		return orderDAO.save(order);
	}
	

}
