package com.cg.ordering.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.ordering.exceptions.CustomerDetailsNotFoundException;
import com.cg.ordering.response.OrderResponse;
@ControllerAdvice
public class PizzaOrdeingExceptionAspect {
	@ExceptionHandler(CustomerDetailsNotFoundException.class)
	public ResponseEntity<OrderResponse> handleAssociateDetailsNotFoundException(Exception e) {
		OrderResponse response=new OrderResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
}
