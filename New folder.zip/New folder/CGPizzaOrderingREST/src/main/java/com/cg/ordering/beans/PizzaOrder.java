package com.cg.ordering.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class PizzaOrder {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderId;
	private int quantity;
	private String pizzaSize;
	private String pizzaType;
	private double orderTotal;
	@ManyToOne
	private Customer customer;
	public PizzaOrder() {}
	
	public PizzaOrder(Customer customer) {
		super();
		this.customer = customer;
	}

	public PizzaOrder(int orderId, int quantity, String pizzaSize, String pizzaType, double orderTotal,
			Customer customer) {
		super();
		this.orderId = orderId;
		this.quantity = quantity;
		this.pizzaSize = pizzaSize;
		this.pizzaType = pizzaType;
		this.orderTotal = orderTotal;
		this.customer = customer;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getPizzaSize() {
		return pizzaSize;
	}
	public void setPizzaSize(String pizzaSize) {
		this.pizzaSize = pizzaSize;
	}
	public String getPizzaType() {
		return pizzaType;
	}
	public void setPizzaType(String pizzaType) {
		this.pizzaType = pizzaType;
	}
	public double getOrderTotal() {
		return orderTotal;
	}
	public void setOrderTotal(double orderTotal) {
		this.orderTotal = orderTotal;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "PizzaOrder [orderId=" + orderId + ", quantity=" + quantity + ", pizzaSize=" + pizzaSize + ", pizzaType="
				+ pizzaType + ", orderTotal=" + orderTotal + ", customer=" + customer + "]";
	}
}
