package com.cg.ordering.services;

import java.util.List;

import com.cg.ordering.beans.Customer;
import com.cg.ordering.beans.PizzaOrder;
import com.cg.ordering.exceptions.CustomerDetailsNotFoundException;
import com.cg.ordering.exceptions.OrderDetailsNotFoundException;

public interface PizzaOrderServices {
 Customer acceptCustomerDetails(Customer customer);
 PizzaOrder acceptOrderDetails(PizzaOrder order);
 Customer getCustomerDetails(int customerId) throws CustomerDetailsNotFoundException;
 List<Customer> getAllCustomerDetails();
 PizzaOrder getOrderDetails(int orderId) throws OrderDetailsNotFoundException;
 boolean removeOrder(int orderId);
 List<PizzaOrder> getAllOrderDetails();
 double calculateBillAmount(int customerId,int orderId,int quantity) throws CustomerDetailsNotFoundException;
PizzaOrder acceptOrderDetails(int customerId, PizzaOrder order) throws CustomerDetailsNotFoundException;
}
