package com.cg.ordering.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ordering.beans.PizzaOrder;

public interface	PizzaOrderDAO extends JpaRepository<PizzaOrder, Integer> {
}
