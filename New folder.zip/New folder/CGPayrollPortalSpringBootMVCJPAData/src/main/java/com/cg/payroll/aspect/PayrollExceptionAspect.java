package com.cg.payroll.aspect;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

@ControllerAdvice
public class PayrollExceptionAspect {
	@ExceptionHandler(AccountNotFoundException.class)
public ModelAndView handleAccountDetailsNotFoundException(Exception e) {
	return new ModelAndView("findAccountDetailsPage","errorMessage",e.getMessage());
}
}
