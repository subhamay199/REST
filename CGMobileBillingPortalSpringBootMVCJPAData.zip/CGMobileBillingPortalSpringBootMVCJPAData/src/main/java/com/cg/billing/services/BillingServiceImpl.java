package com.cg.billing.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.dao.BillDAO;
import com.cg.billing.dao.CustomerDAO;
import com.cg.billing.dao.PlanDAO;
import com.cg.billing.dao.PostPaidAccountDAO;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;

@Component("billingServices")
public class BillingServiceImpl implements BillingServices{
	@Autowired
	BillDAO billDao;
	@Autowired
	CustomerDAO customerDao;
	@Autowired
	PlanDAO planDao;
	@Autowired
	PostPaidAccountDAO postpaidAccountDao;
	Customer customer=new Customer();
	PostpaidAccount postpaidAccount;
	Bill bills;
	Plan plans;

	public BillingServiceImpl(BillDAO billDao, CustomerDAO customerDao, PlanDAO planDao, PostPaidAccountDAO postpaidAccountDao) {
		super();
		this.billDao = billDao;
		this.customerDao = customerDao;
		this.planDao = planDao;
		this.postpaidAccountDao = postpaidAccountDao;
	}

	public BillingServiceImpl() {}

	@Override
	public Customer acceptCustomerDetails(Customer customer) {
		customer=customerDao.save(customer);
		return customer;
	}
	
	@Override
	public Customer getCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		return customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer Data Not Found for Customer Id "+customerID));
	}
	
	@Override
	public List<Customer> getAllCustomerDetails() {
		return customerDao.findAll();
	}
	
	@Override
	public boolean removeCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		customerDao.deleteById(customerID);
		return true;
	}
	
	@Override
	public PostpaidAccount openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		Plan plan = planDao.findById(planID).orElseThrow(() -> new PlanDetailsNotFoundException("No such plan ID " + planID + " found"));
		Customer customer = getCustomerDetails(customerID);
		PostpaidAccount postpaidAccount= postpaidAccountDao.save(new PostpaidAccount(plan, customer));
			return postpaidAccount;
	}
	
	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		return postpaidAccountDao.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("PostPaid Account Details Not Found for customer Id"+mobileNo)) ;
	}
	
	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException {
		return postpaidAccountDao.findAll();
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
//		Plan planDetails=planDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer Details Not Found for Customer Id "+customerID));
//		PostpaidAccount postpaidAccountDetails=postpaidAccountDao.findById(mobileNo).orElseThrow(()->new CustomerDetailsNotFoundException("Customer Details Not Found for Customer Id "+customerID));
		//Plan plansDetails= planDao.save(new Plan(customerID, mobileNo));
		//return plansDetails;
		Plan plan=getPostPaidAccountDetails(customerID, mobileNo).getPlan();
		return plan;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		postpaidAccountDao.deleteById(postpaidAccount.getMobileNo());
		//postpaidAccountDao.delete(postpaidAccountDao) ;
		return true;
	}
	
	@Override
	public List<Plan> getPlanAllDetails() {
		return (List<Plan>) planDao.findAll();
	}
	
	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		PostpaidAccount postpaidAccount=getPostPaidAccountDetails(customerID, mobileNo);
		postpaidAccount.setPlan(planDao.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException("Plan Details Not Found for Plan ID: "+planID)));
		postpaidAccountDao.save(postpaidAccount);
		return true;
	}
	
//	@Override
//	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
//			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
//			BillDetailsNotFoundException {
//		postpaidAccount=getPostPaidAccountDetails(customerID, mobileNo);
//		List<Bill> bills=new ArrayList<Bill>(postpaidAccount.getBills().values());
//		Bill bill = null;
//		for(Bill b:bills) {bill=b;}
//		return bill;
//	}
//	
	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		return new ArrayList<Bill>(getPostPaidAccountDetails(customerID, mobileNo).getBills().values());
	}

//	@Override
//	public double generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth)
//				throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {
//		double totalBillAmount=(bills.getNoOfLocalCalls()-plans.getFreeLocalCalls())*plans.getLocalCallRate()+
//				(bills.getNoOfLocalSMS()-plans.getFreeLocalSMS())*plans.getLocalSMSRate()+
//				(bills.getNoOfStdCalls()-plans.getFreeStdCalls())*plans.getStdCallRate()+(bills.getNoOfStdSMS()-plans.getFreeStdSMS())*plans.getStdSMSRate()+
//				(bills.getInternetDataUsageUnits()-plans.getFreeInternetDataUsageUnits())*plans.getInternetDataUsageRate();
//		customer=customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer Details Not Found For The Customer "+customerID));
//		Map<Long, PostpaidAccount> post=customer.getPostpaidAccounts();
//		PostpaidAccount account=post.get(mobileNo);
////		plans=account.getPlan();
////		bills.totalBillAmount=plans.getInternetDataUsageRate()+plans. getLocalSMSRate()+plans.getLocalCallRate()+plans.getStdCallRate()+plans.getStdSMSRate();
////		total+=(0.09*2)*total;
////		Bill bill=new Bill(localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount);
//		bills.setTotalBillAmount((float) totalBillAmount);
//		billDao.save(bills);
//		account.getBills().put(bills.getBillID(), bills);
//		postpaidAccountDao.save(account);
//		bills.setPostpaidAccount(postpaidAccount);
//		billDao.save(bills);
//		return totalBillAmount;
//	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {

		float internetDataUsageAmount=0,localCallAmount=0,stdCallAmount=0,localSMSAmount=0,stdSMSAmount=0,totalBillAmount=0,stateGST, centralGST;
		Customer customer= customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer ID is Invalid"));
		Map<Long, PostpaidAccount> postpaidMap=customer.getPostpaidAccounts();
		PostpaidAccount acc=postpaidMap.get(mobileNo);
		Plan p=acc.getPlan();
		
		 totalBillAmount=(bills.getNoOfLocalCalls()-plans.getFreeLocalCalls())*plans.getLocalCallRate()+
	(bills.getNoOfLocalSMS()-plans.getFreeLocalSMS())*plans.getLocalSMSRate()+
			(bills.getNoOfStdCalls()-plans.getFreeStdCalls())*plans.getStdCallRate()+(bills.getNoOfStdSMS()-plans.getFreeStdSMS())*plans.getStdSMSRate()+
			(bills.getInternetDataUsageUnits()-plans.getFreeInternetDataUsageUnits())*plans.getInternetDataUsageRate();
		 stateGST=(float) (.09*totalBillAmount);
			centralGST=(float) (.09*totalBillAmount);
		totalBillAmount+=(stateGST+centralGST);
		 Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, stateGST, centralGST);
		billDao.save(bill);
		acc.getBills().put(bill.getBillID(), bill);
		bill.setPostpaidAccount(postpaidAccountDao.save(acc));
		
		billDao.save(bill);
		return totalBillAmount;
	}	
}
