package com.cg.billing.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;


@Controller
public class BillingServicesController {

	@Autowired
	BillingServices billingServices;

	@RequestMapping("/registerCustomer")
	public ModelAndView registerAssociate(@Valid@ModelAttribute Customer customer,BindingResult result) {
		if(result.hasErrors()) return new ModelAndView("registrationPage");
		customer=billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("registrationSuccessPage","customer",customer);
	}

	@RequestMapping("/customerDetails")
	public ModelAndView getCustomerDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException {
		Customer customer=billingServices.getCustomerDetails(customerID);
		return new ModelAndView("findCustomerDetailsPage","customer",customer);
	}
	@RequestMapping("/customerAllDetails")
	public ModelAndView getAllCustomerDetails() throws CustomerDetailsNotFoundException {
		List<Customer> customers=billingServices.getAllCustomerDetails();
		return new ModelAndView("findCustomerAllDetailsPage","customers",customers);
	}
	@RequestMapping("/removeC")
	public ModelAndView removeCustomerDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException {
		boolean rem=billingServices.removeCustomerDetails(customerID);
		return new ModelAndView("removeCustomerSuccessPage","rem",rem);
	}
	@RequestMapping("/postpaidAccount")
	public ModelAndView openPostpaidAccount(@RequestParam int customerID,@RequestParam int planID) throws  PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		PostpaidAccount postpaidAccount=billingServices.openPostpaidMobileAccount(customerID, planID);
		return new ModelAndView("postpaidAccountSuccess","postpaidAccount",postpaidAccount);
	}
	@RequestMapping("/getPostpaidDetails")
	public ModelAndView getPostpaidDetails(@RequestParam int customerID,@RequestParam long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		PostpaidAccount postpaidAccount=billingServices.getPostPaidAccountDetails(customerID, mobileNo);
		return new ModelAndView("getPostPaidAccountDetailsPage","postpaidAccount",postpaidAccount);
	}
	@RequestMapping("/cust")
	public ModelAndView customerAllPostpaidAccountsPage(@RequestParam int customerID) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		List<PostpaidAccount> postpaidAccounts=billingServices.getCustomerAllPostpaidAccountsDetails(customerID);
		return new ModelAndView("customerAllPostpaidAccountPage","postpaidAccounts",postpaidAccounts);
	}
	
	@RequestMapping("/custPostPlanDetails")
	public ModelAndView getCustomerPostPaidAccountPlanDetails(@RequestParam int customerID, @RequestParam long mobileNo) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		Plan postpaidAccounts=billingServices.getCustomerPostPaidAccountPlanDetails(customerID, mobileNo);
		return new ModelAndView("customerPostPaidAccountPlanPage","postpaidAccounts",postpaidAccounts);
	}
	
	@RequestMapping("/removepost")
	public ModelAndView removePostpaidAccountDetails(@RequestParam int customerID,@RequestParam long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		boolean rem=billingServices.closeCustomerPostPaidAccount(customerID, mobileNo);
		return new ModelAndView("removeCustomer","rem",rem);
	}
	@RequestMapping("/planAllDetails")
	public ModelAndView getAllPlanDetails() throws PlanDetailsNotFoundException {
		List<Plan> plans=billingServices.getPlanAllDetails();
		return new ModelAndView("findPlanAllDetailsPage","plans",plans);
	}
	@RequestMapping("/changingPlan")
	public ModelAndView changePlan(@RequestParam int customerID,@RequestParam long mobileNo,@RequestParam int planID) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		boolean change=billingServices.changePlan(customerID, mobileNo, planID);
		return new ModelAndView("changePlanPage","change",change);
	}
	@RequestMapping("/mobileDetails")
	public ModelAndView getMobileDetails(@RequestParam int customerID,@RequestParam long mobileNo,@RequestParam String billMonth) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		Bill bill=billingServices.getMobileBillDetails(customerID, mobileNo, billMonth);
		return new ModelAndView("findMobileBillDetailsPage","bill",bill);
	}
	@RequestMapping("/custPostBillDetails")
	public ModelAndView getCustomerPostPaidAccountAllBillDetailsPage(@RequestParam int customerID, @RequestParam long mobileNo) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		 List<Bill> bills=billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
		return new ModelAndView("getCustomerPostPaidAccountAllBillDetailsPage","bills",bills);
	}
	@RequestMapping("/monthlyDetails")
	public ModelAndView monthlyDetails(@RequestParam int customerID, @RequestParam long mobileNo,String billMonth,@RequestParam int noOfLocalSMS,
			@RequestParam int noOfStdSMS,@RequestParam int noOfLocalCalls,@RequestParam int noOfStdCalls,@RequestParam int internetDataUsageUnits) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		double bill=billingServices.generateMonthlyMobileBill(customerID, mobileNo, billMonth,noOfLocalSMS,noOfStdSMS,noOfLocalCalls,noOfStdCalls,internetDataUsageUnits);
		return new ModelAndView("monthlyMobileBillPage","bill",bill);
		//return new ModelAndView("monthlyMobileBillPage","bill",bill);
	}
}
