package com.cg.billing.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.billing.beans.Customer;

@Controller
public class URIController {

	private Customer customer;

	@RequestMapping(value={"/","index"})
	public String getIndexPage() {
		return "indexPage";
	}

	@RequestMapping("/RegistrationPage")
	public String getRegistrationPage() {
		return "registrationPage";
	}
	
	@RequestMapping("/findCustomerDetails")
	public String getFindCustomerDetailsPage() {
		return "findCustomerDetailsPage";
	}
	@RequestMapping("/findAllCustomerDetails")
	public String getFindAllCustomerDetailsPage() {
		return "findCustomerAllDetailsPage";
	}
	@RequestMapping("/removeCust")
	public String removeCustomerPage() {
		return "removeCustomer";
	}
	@RequestMapping("/openPostpaidAccount")
	public String getOpenPostPaidAccountPage() {
		return "openPostPaidAccountPage";
	}
	@RequestMapping("/getPostPaidAccountDetails")
	public String getgetPostPaidAccountDetailsPage() {
		return "getPostPaidAccountDetailsPage";
	}
	@RequestMapping("/postCustomer")
	public String getCustomerAllPostpaidAccountsDetails() {
		return "customerAllPostpaidAccountPage";
	}
	@RequestMapping("/postAccPlanCustomer")
	public String getCustomerPostPaidAccountPlanDetails() {
		return "customerPostPaidAccountPlanPage";
	}
	
	@RequestMapping("/removePost")
	public String removePostpaidAccountPage() {
		return "removePostpaidAccountPage";
	}
	@RequestMapping("/findAllPlanDetails")
	public String getFindAllPlanDetailsPage() {
		return "findPlanAllDetailsPage";
	}
	@RequestMapping("/changePlan")
	public String changePlanPage() {
		return "changePlanPage";
	}
	@RequestMapping("/findMobileBillDetails")
	public String getfindMobileBillDetailsPage() {
		return "findMobileBillDetailsPage";
	}
	@RequestMapping("/custCustomerBill")
	public String getCustomerPostPaidAccountAllBillDetailsPage() {
		return "getCustomerPostPaidAccountAllBillDetailsPage";
	}
	@RequestMapping("/monthlyBill")
	public String monthlyMobileBillPage() {
		return "monthlyMobileBillPage";
	}
	@ModelAttribute
	public Customer getCustomer() {
		customer=new Customer();
		return customer;
	}
}
